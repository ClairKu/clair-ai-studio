盈米AI能力全景 · 双模板展示包 · 2026-10-28

打开 index.html 选择模板；briefing/index.html 为战略叙事版，atlas/index.html 为场景探索版。
两套模板均为自包含HTML，支持手机浏览、场景切换、流程阅读和打印；页面底部提供原版、对比入口及另一模板导航。
sources.json 为来源与数据口径；两张 PNG 为实际桌面预览。

内容：12类场景、8项产品平台、5层共享底座、7条流程示意、组织治理、公开发展节点及合作起步建议。
数据：OAP截至2026-10-01；AI小顾截至2026-09-01；证据核验沿用原版2026-10-27。本次2026-10-28为展示与信息编排修订。
13项公开来源及原始实践材料归纳说明随页列出。内部原稿、明细和内部链接不在此包内。

生产入口：https://clairku.github.io/clair-ai-studio/reports/yingmi-ai-capabilities-two-templates-2026-10-28/
